# 自由导航
> 自用导航页，简单、自由。

原项目：https://github.com/5iux/sou
使用其前端样式，重写部分代码，去除了不需要的模块

###  GIF

![自由导航](https://github.com/yeetime/sou2/blob/master/sou2.gif)
> （图片效果，以实际页面为准）

## 示例页面：

+ [https://www.alone.run/](https://www.alone.run/)

## 组件：

### 图标：
图标调用了阿里的图标 [https://www.iconfont.cn/](https://www.iconfont.cn/)
